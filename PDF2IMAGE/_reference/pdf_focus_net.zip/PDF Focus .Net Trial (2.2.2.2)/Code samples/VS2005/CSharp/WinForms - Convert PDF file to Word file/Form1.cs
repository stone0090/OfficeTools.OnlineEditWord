using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace Sample
{
	public class Form1 : System.Windows.Forms.Form
	{
        private Button button1;
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(84, 90);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 85);
            this.button1.TabIndex = 0;
            this.button1.Text = "Go";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "PDF Focus .Net sample";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

		}
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
	
		}

        private void button1_Click(object sender, EventArgs e)
        {
            string pathToPdf = @"..\..\..\..\..\text and graphics.pdf";
            string pathToWord = @"..\..\..\..\..\Result.rtf";

            //Convert PDF file to Word file
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            f.OpenPdf(pathToPdf);

            if (f.PageCount > 0)
            {
                int result = f.ToWord(pathToWord);
                
                //Show Word document
                if (result==0)
                {
                    System.Diagnostics.Process.Start(pathToWord);
                }
            }
        }
 	}
}
