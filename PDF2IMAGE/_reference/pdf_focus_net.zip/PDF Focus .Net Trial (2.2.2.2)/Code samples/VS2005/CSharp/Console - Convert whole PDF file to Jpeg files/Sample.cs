using System;
using System.IO;

namespace Sample
{
    class Sample
    {
        static void Main(string[] args)
        {
            //Convert whole PDF file to Jpeg files
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            string pdfPath = @"..\..\..\..\..\simple text.pdf";
            string imageFolder = @"..\..\..\..\..\";

            f.OpenPdf(pdfPath);

            if (f.PageCount > 0)
            {
                //Set image properties: Jpeg, 200 dpi
                f.ImageOptions.ImageFormat = System.Drawing.Imaging.ImageFormat.Jpeg;
                f.ImageOptions.Dpi = 200;

                //Save all PDF pages to image folder, each file will have name page1.jpg, page2.jpg, pageN.jpg
                int result = f.ToImage(imageFolder, "page");

                // 0 - saving successfully                
                // 2 - can't create output file, check the output path
                // 3 - saving failed
                if (result == 0)
                {
                    System.Diagnostics.Process.Start(imageFolder);
                }
            }
        }
    }
}
