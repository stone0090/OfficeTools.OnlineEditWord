using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace Sample
{
	public class Form1 : System.Windows.Forms.Form
	{
        private Button button1;
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();
		}
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(84, 90);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 85);
            this.button1.TabIndex = 0;
            this.button1.Text = "Go";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "PDF Focus .Net sample";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

		}
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
	
		}

        private void button1_Click(object sender, EventArgs e)
        {
            byte [] pdf = ReadBytesFromFile(@"..\..\..\..\..\simple text.pdf");
            string word = "";

            //Convert PDF to word in memory
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            f.OpenPdf(pdf);

            if (f.PageCount > 0)
            {
                word = f.ToWord();

                //Save word document from string to file to show it in MS Word
                if (word != "")
                {
                    //3. Save to RTF document
                    if (WriteToFile(@"..\..\..\..\..\Result.doc", word)==0)
                        System.Diagnostics.Process.Start(@"..\..\..\..\..\Result.doc");
                }

            }
        }
		public static byte[] ReadBytesFromFile(string fileName)
        {
            byte[] buff = null;
            try
            {
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(fileName).Length;
                buff = br.ReadBytes((int)numBytes);
            }
            catch { }
            return buff;
        }
        public static int WriteToFile(string fileName, string contents)
        {
            try
            {
                StreamWriter sw = new StreamWriter(fileName);
                sw.Write(contents);
                sw.Close();
            }
            catch
            {
                return 2;
            }
            return 0;
        }

 	}
}
