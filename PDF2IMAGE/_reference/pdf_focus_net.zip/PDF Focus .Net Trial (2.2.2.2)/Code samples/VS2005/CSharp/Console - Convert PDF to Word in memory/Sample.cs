using System;
using System.IO;

namespace Sample
{
    class Sample
    {
        static void Main(string[] args)
        {
            byte [] pdf = ReadBytesFromFile(@"..\..\..\..\..\simple text.pdf");
            string word = "";

            //Convert PDF to word in memory
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            f.OpenPdf(pdf);

            if (f.PageCount > 0)
            {
                word = f.ToWord();

                //Save word document from string to file to show it in MS Word
                if (word != "")
                {
                    //3. Save to RTF document
                    if (WriteToFile(@"..\..\..\..\..\Result.doc", word)==0)
                        System.Diagnostics.Process.Start(@"..\..\..\..\..\Result.doc");
                }

            }
        }
        public static byte[] ReadBytesFromFile(string fileName)
        {
            byte[] buff = null;
            try
            {
                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                long numBytes = new FileInfo(fileName).Length;
                buff = br.ReadBytes((int)numBytes);
            }
            catch { }
            return buff;
        }
        public static int WriteToFile(string fileName, string contents)
        {
            try
            {
                StreamWriter sw = new StreamWriter(fileName);
                sw.Write(contents);
                sw.Close();
            }
            catch
            {
                return 2;
            }
            return 0;
        }

    }
}
