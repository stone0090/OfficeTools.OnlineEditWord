using System;
using System.IO;

namespace Sample
{
    class Sample
    {
        static void Main(string[] args)
        {
            string pathToPdf = @"..\..\..\..\..\Text.pdf";
            string pathToText = @"..\..\..\..\..\Result.txt";

            //Convert PDF file to Text file
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            f.OpenPdf(pathToPdf);

            if (f.PageCount > 0)
            {
                int result = f.ToText(pathToText);
                
                //Show Text document
                if (result==0)
                {
                    System.Diagnostics.Process.Start(pathToText);
                }
            }
        }
    }
}
