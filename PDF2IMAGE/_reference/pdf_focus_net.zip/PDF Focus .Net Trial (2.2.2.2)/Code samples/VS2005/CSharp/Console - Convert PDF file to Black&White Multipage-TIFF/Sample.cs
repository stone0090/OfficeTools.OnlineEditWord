using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace Sample
{
    class Sample
    {
        static void Main(string[] args)
        {
            //Convert PDF file to Black&White Multipage-TIFF
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
	    	//this property is necessary only for registered version
		    //f.Serial = "XXXXXXXXXXX";

            string pdfPath = @"..\..\..\..\..\simple text.pdf";
            string tiffPath = @"..\..\..\..\..\Result.tiff";

            f.OpenPdf(pdfPath);

            if (f.PageCount > 0)
            {
                f.ImageOptions.Dpi = 120;
                //EncoderValue.CompressionCCITT4 - makes image black&white 1 bit
                if (f.ToMultipageTiff(tiffPath, EncoderValue.CompressionCCITT4) == 0)
                {
                    System.Diagnostics.Process.Start(tiffPath);
                }
            }            
        }
    }
}
