Imports System.IO
Module Sample

    Sub Main()
        Dim pathToPdf As String = "..\..\..\..\text and graphics.pdf"
        Dim pathToWord As String = "..\..\..\..\Result.rtf"

        'Convert PDF file to Word file
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        f.OpenPdf(pathToPdf)

        If f.PageCount > 0 Then
            Dim result As Integer = f.ToWord(pathToWord)

            'Show Word document
            If result = 0 Then
                System.Diagnostics.Process.Start(pathToWord)
            End If
        End If
    End Sub
End Module
