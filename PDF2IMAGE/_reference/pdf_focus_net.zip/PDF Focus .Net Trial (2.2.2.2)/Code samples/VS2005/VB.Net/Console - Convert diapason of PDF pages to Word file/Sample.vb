Imports System.IO
Module Sample

    Sub Main()
        Dim pathToPdf As String = "..\..\..\..\simple text.pdf"
        Dim pathToWord As String = "..\..\..\..\Result.rtf"

        'Convert diapason of PDF pages to Word file
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        f.OpenPdf(pathToPdf)

        If f.PageCount > 0 Then
            'Convert only pages 2 - 4 to Word
            Dim result As Integer = f.ToWord(pathToWord, 2, 4)

            'Show Word document
            If result = 0 Then
                System.Diagnostics.Process.Start(pathToWord)
            End If
        End If
    End Sub
End Module
