Imports System.IO
Module Sample

    Sub Main()
        'Convert PDF 1st page to PNG file
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        Dim pdfPath As String = "..\..\..\..\simple text.pdf"
        Dim imagePath As String = "..\..\..\..\Result.png"

        f.OpenPdf(pdfPath)

        If f.PageCount > 0 Then
            'In most cases we recommend to set 120 dpi to decrease the image size and converting speed
            'Now set 300 dpi - very high quality
            f.ImageOptions.Dpi = 300

            'save 1st page to png file, 300 dpi
            If f.ToImage(imagePath, 1) = 0 Then
                ' 0 - converting successfully                
                ' 2 - can't create output file, check the output path
                ' 3 - converting failed
                System.Diagnostics.Process.Start(imagePath)
            End If
        End If
    End Sub
End Module
