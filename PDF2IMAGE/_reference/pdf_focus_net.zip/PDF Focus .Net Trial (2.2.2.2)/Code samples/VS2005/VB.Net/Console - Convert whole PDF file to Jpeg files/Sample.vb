Imports System.IO
Module Sample

    Sub Main()
        'Convert whole PDF file to Jpeg files
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        Dim pdfPath As String = "..\..\..\..\simple text.pdf"
        Dim imageFolder As String = "..\..\..\..\"

        f.OpenPdf(pdfPath)

        If f.PageCount > 0 Then
            'Set image properties: Jpeg, 200 dpi
            f.ImageOptions.ImageFormat = System.Drawing.Imaging.ImageFormat.Jpeg
            f.ImageOptions.Dpi = 200

            'Save all PDF pages to image folder, each file will have name page1.jpg, page2.jpg, pageN.jpg

            Dim result As Integer = f.ToImage(imageFolder, "page")

            ' 0 - saving successfully                
            ' 2 - can't create output file, check the output path
            ' 3 - saving failed
            If result = 0 Then
                System.Diagnostics.Process.Start(imageFolder)
            End If
        End If
    End Sub
End Module
