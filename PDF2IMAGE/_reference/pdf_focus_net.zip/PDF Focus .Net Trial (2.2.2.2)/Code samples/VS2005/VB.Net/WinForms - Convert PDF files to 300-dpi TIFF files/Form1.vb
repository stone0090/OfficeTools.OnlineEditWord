Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(84, 90)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(116, 85)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Go"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "PDF Focus .Net sample"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Convert PDF files to 300-dpi TIFF files
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        Dim pdfFiles() As String = Directory.GetFiles("..\..\..\..\", "*.pdf")
        Dim folderWithTiffs As String = "..\..\..\..\"

        For Each pdffile As String In pdfFiles
            f.OpenPdf(pdffile)

            If f.PageCount > 0 Then
                'Set image format: TIFF, 300 dpi
                f.ImageOptions.Dpi = 300
                f.ImageOptions.ImageFormat = System.Drawing.Imaging.ImageFormat.Tiff

                'Save all pages to tiff files with 300 dpi
                f.ToImage(folderWithTiffs, Path.GetFileNameWithoutExtension(pdffile))
            End If
            f.ClosePdf()
        Next pdffile
        'Show folder with tiffs
        System.Diagnostics.Process.Start(folderWithTiffs)
    End Sub
End Class
