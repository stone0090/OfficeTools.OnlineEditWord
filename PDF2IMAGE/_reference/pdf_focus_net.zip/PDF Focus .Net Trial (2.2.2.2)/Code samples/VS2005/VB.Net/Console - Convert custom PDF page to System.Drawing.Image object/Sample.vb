Imports System.IO
Module Sample

    Sub Main()
        'Convert custom PDF page to Image object
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        Dim pdfPath As String = "..\..\..\..\simple text.pdf"
        Dim imagePath As String = "..\..\..\..\Result.png"

        ' 0 - converting successfully
        ' 1 - can't open input file or URL, check the input path
        ' 2 - can't create output file, check the output path
        ' 3 - converting failed
        f.OpenPdf(pdfPath)

        If f.PageCount > 0 Then
            'Let's convert 1st page into System.Drawing.Image object, 120 dpi
            f.ImageOptions.Dpi = 120
            Dim img As System.Drawing.Image = f.ToDrawingImage(1)

            'Save to file
            If img IsNot Nothing Then
                img.Save(imagePath)
                System.Diagnostics.Process.Start(imagePath)
            End If
        End If
    End Sub
End Module
