Imports System.IO
Module Sample

    Sub Main()
        Dim pdf() As Byte = ReadBytesFromFile("..\..\..\..\simple text.pdf")
        Dim word As String = ""

        'Convert PDF to word in memory
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        f.OpenPdf(pdf)

        If f.PageCount > 0 Then
            word = f.ToWord()

            'Save word document from string to file to show it in MS Word
            If word <> "" Then
                '3. Save to RTF document
                If WriteToFile("..\..\..\..\Result.doc", word) = 0 Then
                    System.Diagnostics.Process.Start("..\..\..\..\Result.doc")
                End If
            End If

        End If
    End Sub
    Public Function ReadBytesFromFile(ByVal fileName As String) As Byte()
        Dim buff() As Byte = Nothing
        Try
            Dim fs As New FileStream(fileName, FileMode.Open, FileAccess.Read)
            Dim br As New BinaryReader(fs)
            Dim numBytes As Long = New FileInfo(fileName).Length
            buff = br.ReadBytes(CInt(Fix(numBytes)))
        Catch
        End Try
        Return buff
    End Function
    Public Function WriteToFile(ByVal fileName As String, ByVal contents As String) As Integer
        Try
            Dim sw As New StreamWriter(fileName)
            sw.Write(contents)
            sw.Close()
        Catch
            Return 2
        End Try
        Return 0
    End Function
End Module
