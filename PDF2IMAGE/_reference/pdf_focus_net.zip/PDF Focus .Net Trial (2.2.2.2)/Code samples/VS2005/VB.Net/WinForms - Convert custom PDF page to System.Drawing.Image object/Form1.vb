Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Private components As System.ComponentModel.IContainer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(84, 90)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(116, 85)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Go"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(284, 264)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "PDF Focus .Net sample"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Convert custom PDF page to Image object
        Dim f As New SautinSoft.PdfFocus()
	    'this property is necessary only for registered version
		'f.Serial = "XXXXXXXXXXX"

        Dim pdfPath As String = "..\..\..\..\simple text.pdf"
        Dim imagePath As String = "..\..\..\..\Result.png"

        ' 0 - converting successfully
        ' 1 - can't open input file or URL, check the input path
        ' 2 - can't create output file, check the output path
        ' 3 - converting failed
        f.OpenPdf(pdfPath)

        If f.PageCount > 0 Then
            'Let's convert 1st page into System.Drawing.Image object, 120 dpi
            f.ImageOptions.Dpi = 120
            Dim img As System.Drawing.Image = f.ToDrawingImage(1)

            'Save to file
            If img IsNot Nothing Then
                img.Save(imagePath)
                System.Diagnostics.Process.Start(imagePath)
            End If
        End If
    End Sub
End Class
